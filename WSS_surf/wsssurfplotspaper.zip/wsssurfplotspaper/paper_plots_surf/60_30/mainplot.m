clc
close all

format long

fs = 30;
filename0 = sprintf('wss_DNS.csv');
M0 = csvread(filename0, 1, 0);

y_uniform = linspace(-3.108800000000000, 3.108800000000000, 100);
x_uniform = linspace(0, 5, 100);
[X_uniform, Y_uniform] = meshgrid(x_uniform, y_uniform);

Y_pred_grid = csvread('MFsurf60_30.csv');
Y_truth_grid = csvread('Truthsurf60_30.csv');
Y_DNS_gpr = csvread('DNSGPsurfE60_30.csv');
Y_RANS_gpr = csvread('RANSGPsurf60_30.csv');

% Common figure size and aspect ratio
figWidth = 8;  % inches
figHeight = 8; % inches

% Loop through figure creation and saving
figureNames = {'MF_60_30.pdf', 'HF_60_30.pdf', 'LF_60_30.pdf', ...
    'True_60_30.pdf', 'ABSE_60_30.pdf', 'ABSERANS_60_30.pdf', 'ABSEDNS_60_30.pdf'};

figureTitles = {'Predictions', 'DNS-GPR', 'RANS-GPR', ...
    'True', 'Error (MF)', 'Error (RANS)', 'Error (DNS)'};

figureData = {Y_pred_grid, Y_DNS_gpr, Y_RANS_gpr, ...
    transpose(Y_truth_grid), abs((Y_pred_grid) - transpose(Y_truth_grid)), ...
    abs((Y_RANS_gpr) - transpose(Y_truth_grid)), ...
    abs((Y_DNS_gpr) - transpose(Y_truth_grid))};

for i = 1:numel(figureNames)
     figure('visible', 'off'); 
    surf(X_uniform, Y_uniform, transpose(figureData{i}));
    colormap("jet");
    view(2);
    shading interp;
    colorbar;
    set(gca, 'FontName', 'Times', 'FontSize', fs);
    set(gca, 'TickLabelInterpreter', 'latex');
    set(0, 'defaultTextInterpreter', 'latex');
    xlim([0, 5]);
    ylim([-pi, pi]);
    xticks([0, 1, 2, 3, 4, 5]);
    xticklabels({'$2D$', '$3D$', '$4D$', '$5D$', '$6D$', '$7D$'});
    yticks([-pi, -pi/2, 0, pi/2, pi]);
    yticklabels({'$-\pi$', '$-\pi/2$', '$0$', '$\pi/2$', '$\pi$'});
    
    % Set figure size and aspect ratio
    fig = gcf;
    fig.Units = 'inches';
    fig.Position = [0, 0, figWidth, figHeight];
    fig.PaperSize = [figWidth, figHeight];
    fig.PaperPosition = [0, 0, figWidth, figHeight];
    
    % Print the figure to a PDF file
    print(figureNames{i}, '-dpdf', '-r0', '-painters', '-bestfit', '-opengl');
    
    % Add title
    % title(figureTitles{i}, 'Interpreter', 'latex');
end
